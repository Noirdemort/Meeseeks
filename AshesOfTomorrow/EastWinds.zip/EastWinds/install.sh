#!/bin/bash

#  install.sh
#  EastWinds
#
#  Created by Noirdemort on 08/06/19.
#
python3 --version
python3 -m pip install pycrypto
python3 -m pip install pycryptodomex
