import XCTest

import EastWindsTests

var tests = [XCTestCaseEntry]()
tests += EastWindsTests.allTests()
XCTMain(tests)
